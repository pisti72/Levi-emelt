SELECT DISTINCT targy
FROM orak
ORDER BY targy;
