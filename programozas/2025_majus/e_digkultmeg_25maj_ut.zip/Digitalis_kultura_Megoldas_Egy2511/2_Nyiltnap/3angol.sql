SELECT datum, terem, orasorszam
FROM orak
WHERE targy='angol'
ORDER BY datum, orasorszam;
