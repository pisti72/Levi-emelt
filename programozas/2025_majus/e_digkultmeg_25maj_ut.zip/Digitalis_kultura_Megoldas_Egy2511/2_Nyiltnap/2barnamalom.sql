SELECT nev
FROM diakok
WHERE telepules='Barnamalom';
